To run file use commands:

g++ -o test hw1_x.cpp
./test <input.txt>